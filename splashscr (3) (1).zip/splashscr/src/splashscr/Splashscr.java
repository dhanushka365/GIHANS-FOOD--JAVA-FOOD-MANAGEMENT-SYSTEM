
package splashscr;


public class Splashscr {

    
    public static void main(String[] args) {
 scr a =new scr();
user_Login b=new user_Login();
 a.setVisible(true);
  try
  {
      for(int p=0;p<=100;p++)
      { Thread.sleep(90);
          a.jProgressBar1.setValue(p);
          a.jLabel.setText("Loding Please Wait.."+(Integer.toString(p)+" %"));
      

    
      if(p==90)
      {   a.setVisible(false);
          b.setVisible(true);
      }
      }
  }
  catch(InterruptedException e)
  {
      
  }
   
    
}
}
